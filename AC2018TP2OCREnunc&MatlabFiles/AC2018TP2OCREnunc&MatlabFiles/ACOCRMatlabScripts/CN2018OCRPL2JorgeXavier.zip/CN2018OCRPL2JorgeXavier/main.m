%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           Mestrado em Inform�tica Cl�nica e Bioinform�tica              %            
%                                                                         %
%               Computa��o Neuronal e Sistemas Difusos                    %
%                                                                         %
%                  OCR � Optical Character Recognition                    %                                 
%                                                                         %
%             Jorge Melo 2015225571 | Xavier Pinho 2014210242             %
%                                                                         %
%                            2018/2019                                    %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                                     
% Este trabalho tem como objetivo o reconhecimento de caracteres atrav�s e
% redes neuronais

% Arquiteturas de redes neuronais:
%   -Classificador
%   -Classificador+Memoria Associativa(filtro)

% Fun��es de ativa��o:
%   -Hardlim
%   -Purelin
%   -Logsig

% Se desejar testar um dos classificadores, press run:
run('mpaper.m')



